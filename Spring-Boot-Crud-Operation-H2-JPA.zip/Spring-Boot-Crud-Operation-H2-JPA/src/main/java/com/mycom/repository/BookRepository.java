package com.mycom.repository;

import org.springframework.data.repository.CrudRepository;
import com.mycom.model.Book;

//repository that extends CrudRepository  
public interface BookRepository extends CrudRepository<Book, Integer> {
	// no methods
}
