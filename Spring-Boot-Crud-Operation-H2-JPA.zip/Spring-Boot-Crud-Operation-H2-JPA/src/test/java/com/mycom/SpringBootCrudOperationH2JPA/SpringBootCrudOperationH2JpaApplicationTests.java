package com.mycom.SpringBootCrudOperationH2JPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCrudOperationH2JpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
